# Detector on public IoT traffic (IoT-23)

Real IoT captures from the Stratosphere Laboratory's IoT-23 dataset, which the detector was never tuned on. Detection used a 60 s window over traffic in both directions. Every alarm on a benign capture is a false alarm. On malware captures an alarm is *justified* if a connection labelled Malicious overlapped the window, and a malicious second counts as *noticed* if an alarm fired within the window after it.

## Malware traffic: what it noticed

| Capture | Device | Packets | Malicious seconds | Noticed | 95% CI | Alarms | Justified | False-alarm checks | Per hour |
|---|---|---|---|---|---|---|---|---|---|
| m08.pcap | 192.168.100.113 | 16,677 | 14649 | 0.0% | [0-0%] | 0 | 0 | 0 | 0.0 |
| m20.pcap | 192.168.100.103 | 41,207 | 85781 | 3.9% | [4-4%] | 1071 | 899 | 172 | 7.17 |
| m21.pcap | 192.168.100.113 | 41,131 | 85839 | 6.1% | [6-6%] | 1806 | 1769 | 37 | 1.54 |
| m42.pcap | 192.168.1.197 | 22,749 | 12 | 100.0% | [76-100%] | 6815 | 99 | 6716 | 803.88 |

### By what the malware was doing (IoT-23's detailed label)

| Capture | Detailed label | Malicious seconds | Noticed | Plausible names of ours |
|---|---|---|---|---|
| m08.pcap | C&C | 14649 | 0.0% | c2_beaconing, rogue_config_beacon |
| m20.pcap | C&C-Torii | 85781 | 3.9% | c2_beaconing, rogue_config_beacon |
| m21.pcap | C&C-Torii | 85839 | 6.1% | c2_beaconing, rogue_config_beacon |
| m42.pcap | C&C-FileDownload | 11 | 100.0% | firmware_tampering, rogue_config_beacon, data_exfiltration |
| m42.pcap | FileDownload | 7 | 100.0% | firmware_tampering, exploit_payload_injection |

### Did the alarm carry a plausible name?

| Capture | Named a plausible equivalent | Named something else | Label has no equivalent | Names raised |
|---|---|---|---|---|
| m08.pcap | 0 | 0 | 0 | - |
| m20.pcap | 0 | 899 | 0 | credential_replay x597, reconnaissance_port_scan x44, exploit_payload_injection x22, credential_replay_distributed x200, mqtt_message_flood x203, data_exfiltration x5 |
| m21.pcap | 0 | 1769 | 0 | credential_replay x1191, mqtt_message_flood x333, credential_replay_distributed x202, reconnaissance_port_scan x53, data_exfiltration x21, exploit_payload_injection x6 |
| m42.pcap | 0 | 99 | 0 | brute_force x5445, dos_flood x2, credential_replay x543, reconnaissance_port_scan x172, mqtt_message_flood x433, data_exfiltration x45, exploit_payload_injection x118, credential_replay_distributed x57 |

## Label mapping used

| IoT-23 detailed label | Our names |
|---|---|
| PartOfAHorizontalPortScan | reconnaissance_port_scan |
| DDoS | dos_flood, tcp_syn_flood, icmp_ping_flood, slow_loris_exhaustion, mqtt_message_flood, dos_flood_distributed, tcp_syn_flood_distributed, icmp_ping_flood_distributed |
| C&C | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat-Attack | c2_beaconing, rogue_config_beacon |
| C&C-Mirai | c2_beaconing, rogue_config_beacon |
| C&C-Torii | c2_beaconing, rogue_config_beacon |
| C&C-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-HeartBeat-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-PartOfAHorizontalPortScan | reconnaissance_port_scan, c2_beaconing |
| FileDownload | firmware_tampering, exploit_payload_injection |
| Attack | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
