# Detector on public IoT traffic (IoT-23)

Real IoT captures from the Stratosphere Laboratory's IoT-23 dataset, which the detector was never tuned on. Detection used a 5 s window over traffic in inbound directions. Every alarm on a benign capture is a false alarm. On malware captures an alarm is *justified* if a connection labelled Malicious overlapped the window, and a malicious second counts as *noticed* if an alarm fired within the window after it.

## Benign traffic: false alarms

| Capture | Device | Packets | Duration | Flagged checks | Per hour | Acted on (2 in a row) | Per hour | What it was called |
|---|---|---|---|---|---|---|---|---|
| benign_echo.pcap | 192.168.2.3 | 396,648 | 5.49 h | 875 | 159.48 | 154 | 28.069 | reconnaissance_port_scan x21, data_exfiltration x29, dos_flood x430, brute_force x98, exploit_payload_injection x294, buffer_overflow_probe x3 |

## Label mapping used

| IoT-23 detailed label | Our names |
|---|---|
| PartOfAHorizontalPortScan | reconnaissance_port_scan |
| DDoS | dos_flood, tcp_syn_flood, icmp_ping_flood, slow_loris_exhaustion, mqtt_message_flood, dos_flood_distributed, tcp_syn_flood_distributed, icmp_ping_flood_distributed |
| C&C | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat-Attack | c2_beaconing, rogue_config_beacon |
| C&C-Mirai | c2_beaconing, rogue_config_beacon |
| C&C-Torii | c2_beaconing, rogue_config_beacon |
| C&C-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-HeartBeat-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-PartOfAHorizontalPortScan | reconnaissance_port_scan, c2_beaconing |
| FileDownload | firmware_tampering, exploit_payload_injection |
| Attack | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
