# Measured-outcome evaluation

Source `data/evaluation/results_measured.jsonl`: 168 paired trials (0 excluded for an unreadable probe). Detection accuracy 97.6% (shared by all arms; not a policy metric).

Utility = containment x measured containment + service x measured service + intelligence x verified intel - action cost; weights in `config/policies.yaml` `policy.objective`. 95% CIs are bootstrap over trials.

| Arm | Mean utility | 95% CI | Containment (attacks) | Service loss | Intel (attacks) | Exec failures |
|---|---|---|---|---|---|---|
| rule_based | 4.272 | [4.00, 4.56] | 53.9% | 30.4% | 8.8% | 0.0% |
| stackelberg | 7.226 | [7.04, 7.38] | 98.3% | 1.7% | 0.0% | 0.0% |
| ppo | 7.254 | [7.08, 7.40] | 98.8% | 0.0% | 0.0% | 0.0% |
| naive_block_all | 3.940 | [3.90, 3.97] | 98.8% | 94.0% | 0.0% | 0.0% |
| always_allow | 3.000 | [3.00, 3.00] | 0.0% | 0.0% | 0.0% | 0.0% |

## Paired utility differences

| Comparison | Mean diff | 95% CI | Wilcoxon p | Holm p | Sign-test p | Non-tied trials |
|---|---|---|---|---|---|---|
| rule_based_minus_stackelberg | -2.954 | [-3.26, -2.64] | 1.895e-22 | 3.79e-22 | 2.351e-38 | 126/168 |
| rule_based_minus_ppo | -2.981 | [-3.27, -2.68] | 8.042e-24 | 2.412e-23 | 9.184e-41 | 134/168 |
| stackelberg_minus_ppo | -0.027 | [-0.06, 0.00] | 0.6885 | 0.6885 | 0.1516 | 24/168 |
| rule_based_minus_naive_block_all | +0.332 | [0.07, 0.61] | 0.02722 | -- | 0.777 | 112/168 |
| stackelberg_minus_naive_block_all | +3.286 | [3.14, 3.41] | 5.124e-29 | -- | 5.474e-48 | 158/168 |
| ppo_minus_naive_block_all | +3.313 | [3.18, 3.43] | 1.817e-29 | -- | 5.474e-48 | 158/168 |
| rule_based_minus_always_allow | +1.272 | [1.00, 1.56] | 6.31e-15 | -- | 0.0001662 | 158/168 |
| stackelberg_minus_always_allow | +4.226 | [4.04, 4.38] | 5.124e-29 | -- | 5.474e-48 | 158/168 |
| ppo_minus_always_allow | +4.254 | [4.08, 4.40] | 1.817e-29 | -- | 5.474e-48 | 158/168 |

## Do the policies choose different actions?

| Pair | Trials with different actions |
|---|---|
| rule_based_vs_stackelberg | 126/168 (75.0%) |
| rule_based_vs_ppo | 134/168 (79.8%) |
| stackelberg_vs_ppo | 24/168 (14.3%) |

All three identical on 20.2% of trials.

## Sensitivity: same measurements, other objective weights

| Weighting | Ranking (best first) |
|---|---|
| service_heavy | ppo > stackelberg > always_allow > rule_based > naive_block_all |
| containment_heavy | ppo > stackelberg > naive_block_all > rule_based > always_allow |
| no_action_cost | ppo > stackelberg > naive_block_all > rule_based > always_allow |

Stackelberg containment prior vs measured: mean absolute error 0.116 over 90 (action, class) cells.
