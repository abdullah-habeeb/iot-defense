# Strategies against a reactive attacker

Conditions: dos_flood, tcp_syn_flood, icmp_ping_flood, credential_replay. Regret is measured against the best response for that table (0 = best). 'adaptive' = scored over both rounds against the switching attacker; 'standard' = scored on the ordinary one-round table, i.e. what the same choice costs when the attacker does NOT react.

| Arm | models | adaptive regret [95% CI] | standard regret |
|---|---|---|---|
| rule_based | 1 | 2.75 [2.06, 3.43] | 2.67 |
| stackelberg | 1 | 2.17 [2.10, 2.30] | 0.00 |
| stackelberg_anticipating | 1 | 0.56 [0.00, 1.52] | 1.19 |
| ppo_standard | 3 | 2.17 [2.10, 2.30] | 0.00 |
| arbiter_standard_evidence | 1 | 2.17 [2.10, 2.30] | 0.00 |
| arbiter_adaptive_evidence | 1 | 2.17 [2.10, 2.30] | 0.00 |
| arbiter_standard_evidence_anticipating | 1 | 2.17 [2.10, 2.30] | 0.00 |
| arbiter_adaptive_evidence_anticipating | 1 | 0.58 [0.00, 1.57] | 0.38 |
| ppo_adaptive_in_sample | 3 | 0.07 [0.00, 0.20] | 0.40 |

Best response per condition: dos_flood: BLOCK_SOURCE -> THROTTLE; tcp_syn_flood: BLOCK_SOURCE -> QUARANTINE; icmp_ping_flood: BLOCK_SOURCE -> QUARANTINE; credential_replay: BLOCK_SOURCE -> QUARANTINE (standard -> adaptive).

## Does the model's mechanism claim match the measurement?

Stackelberg-with-rotation predicts which responses a rational attacker dodges by switching address; the table shows which actually lost containment after the switch. Agreement: 16/16 (response, attack) pairs.
Predicted dodged but held up: none. Dodged but not predicted: none.

