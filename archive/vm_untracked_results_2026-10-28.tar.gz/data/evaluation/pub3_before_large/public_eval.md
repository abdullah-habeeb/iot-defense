# Detector on public IoT traffic (IoT-23)

Real IoT captures from the Stratosphere Laboratory's IoT-23 dataset, which the detector was never tuned on. Detection used a 5 s window over traffic in inbound directions. Every alarm on a benign capture is a false alarm. On malware captures an alarm is *justified* if a connection labelled Malicious overlapped the window, and a malicious second counts as *noticed* if an alarm fired within the window after it.

## Malware traffic: what it noticed

Noticed at start = an alarm fired within the window after a malicious connection began. Alarm precision = share of alarms raised while a malicious connection was open. Seconds noticed counts every second a malicious connection stays open, so long-lived connections dominate it; treat it as secondary.

| Capture | Device | Packets | Malicious connections | Noticed at start | 95% CI | Alarms | Alarm precision | False-alarm checks per hour | Seconds noticed |
|---|---|---|---|---|---|---|---|---|---|
| m34.pcap | 192.168.1.195 | 4,154 | 284 | 72.9% | [67-78%] | 113 | 83.2% | 38.08 | 65.4% |
| m03.pcap | 192.168.2.5 | 4,753 | 1635 | 30.0% | [28-32%] | 97 | 100.0% | 0.0 | 14.5% |

### By what the malware was doing (IoT-23's detailed label)

| Capture | Detailed label | Connections | Noticed at start | Plausible names of ours |
|---|---|---|---|---|
| m34.pcap | C&C | 284 | 72.9% | c2_beaconing, rogue_config_beacon |
| m03.pcap | Attack | 30 | 96.7% | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
| m03.pcap | C&C | 2 | 0.0% | c2_beaconing, rogue_config_beacon |
| m03.pcap | PartOfAHorizontalPortScan | 1603 | 28.8% | reconnaissance_port_scan |

### Did the alarm carry a plausible name?

| Capture | Named a plausible equivalent | Named something else | Label has no equivalent | Names raised |
|---|---|---|---|---|
| m34.pcap | 0 | 94 | 0 | dos_flood x40, brute_force x52, exploit_payload_injection x1, data_exfiltration x3, reconnaissance_port_scan x17 |
| m03.pcap | 97 | 0 | 0 | exploit_payload_injection x4, reconnaissance_port_scan x2, brute_force x91 |

## Label mapping used

| IoT-23 detailed label | Our names |
|---|---|
| PartOfAHorizontalPortScan | reconnaissance_port_scan |
| DDoS | dos_flood, tcp_syn_flood, icmp_ping_flood, slow_loris_exhaustion, mqtt_message_flood, dos_flood_distributed, tcp_syn_flood_distributed, icmp_ping_flood_distributed |
| C&C | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat-Attack | c2_beaconing, rogue_config_beacon |
| C&C-Mirai | c2_beaconing, rogue_config_beacon |
| C&C-Torii | c2_beaconing, rogue_config_beacon |
| C&C-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-HeartBeat-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-PartOfAHorizontalPortScan | reconnaissance_port_scan, c2_beaconing |
| FileDownload | firmware_tampering, exploit_payload_injection |
| Attack | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
