# Evaluation results

Source: `data/evaluation/results.jsonl` -- 400 rows from 5 trials x 16 conditions x 5 arms, all against real Mininet traffic.

## Comparison summary

| Arm | Detection accuracy | Verified response rate | Matches preferred action (attacks only) | Mean detection latency |
|---|---|---|---|---|
| Rule-based (ours) | 90.0% | 85.0% | 92.0% | 26026 ms |
| Stackelberg (ours, deployed) | 90.0% | 85.0% | 92.0% | 26026 ms |
| PPO (ours) | 90.0% | 85.0% | 92.0% | 26026 ms |
| NaiveBlockAllBaseline | 90.0% | 25.0% | 20.0% | 26026 ms |
| AlwaysAllowBaseline | 90.0% | 6.2% | 0.0% | 26026 ms |

## Per-condition breakdown (Stackelberg -- the policy actually deployed)

| Condition | Detection accuracy | Verified response rate |
|---|---|---|
| `normal` | 100.0% | 100.0% |
| `reconnaissance_port_scan` | 100.0% | 100.0% |
| `dos_flood` | 100.0% | 100.0% |
| `brute_force` | 100.0% | 100.0% |
| `data_exfiltration` | 100.0% | 100.0% |
| `exploit_payload_injection` | 80.0% | 80.0% |
| `tcp_syn_flood` | 60.0% | 100.0% |
| `icmp_ping_flood` | 100.0% | 0.0% |
| `slow_loris_exhaustion` | 40.0% | 20.0% |
| `dns_amplification` | 100.0% | 100.0% |
| `dns_tunneling_exfiltration` | 80.0% | 80.0% |
| `mqtt_message_flood` | 100.0% | 100.0% |
| `firmware_tampering` | 100.0% | 100.0% |
| `buffer_overflow_probe` | 100.0% | 100.0% |
| `credential_replay` | 80.0% | 80.0% |
| `rogue_config_beacon` | 100.0% | 100.0% |

## External detection comparison (Suricata, offline pcap analysis)

80 pcaps analyzed -- see EVALUATION.md for methodology and honest
caveats about run-to-run variance in this section specifically.

| Detector | Accuracy | True positive rate | False positive rate |
|---|---|---|---|
| Suricata + ET-Open (real-world community rules) | 77.5% | 81.3% | 80.0% |
| Suricata + lab-tailored rules (this project's own signatures) | 91.2% | 90.7% | 0.0% |
