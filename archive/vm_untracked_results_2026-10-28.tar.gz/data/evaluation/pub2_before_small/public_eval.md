# Detector on public IoT traffic (IoT-23)

Real IoT captures from the Stratosphere Laboratory's IoT-23 dataset, which the detector was never tuned on. Detection used a 5 s window over traffic in inbound directions. Every alarm on a benign capture is a false alarm. On malware captures an alarm is *justified* if a connection labelled Malicious overlapped the window, and a malicious second counts as *noticed* if an alarm fired within the window after it.

## Malware traffic: what it noticed

Noticed at start = an alarm fired within the window after a malicious connection began. Alarm precision = share of alarms raised while a malicious connection was open. Seconds noticed counts every second a malicious connection stays open, so long-lived connections dominate it; treat it as secondary.

| Capture | Device | Packets | Malicious connections | Noticed at start | 95% CI | Alarms | Alarm precision | False-alarm checks per hour | Seconds noticed |
|---|---|---|---|---|---|---|---|---|---|
| m08.pcap | 192.168.100.113 | 16,677 | 8222 | 0.0% | [0-0%] | 0 | n/a | 0.0 | 0.0% |
| m20.pcap | 192.168.100.103 | 41,207 | 16 | 6.2% | [1-28%] | 5 | 100.0% | 0.0 | 0.0% |
| m21.pcap | 192.168.100.113 | 41,131 | 14 | 21.4% | [8-48%] | 13 | 100.0% | 0.0 | 0.0% |
| m42.pcap | 192.168.1.197 | 22,749 | 6 | 100.0% | [61-100%] | 758 | 2.8% | 88.22 | 100.0% |

### By what the malware was doing (IoT-23's detailed label)

| Capture | Detailed label | Connections | Noticed at start | Plausible names of ours |
|---|---|---|---|---|
| m08.pcap | C&C | 8222 | 0.0% | c2_beaconing, rogue_config_beacon |
| m20.pcap | C&C-Torii | 16 | 6.2% | c2_beaconing, rogue_config_beacon |
| m21.pcap | C&C-Torii | 14 | 21.4% | c2_beaconing, rogue_config_beacon |
| m42.pcap | C&C-FileDownload | 3 | 100.0% | firmware_tampering, rogue_config_beacon, data_exfiltration |
| m42.pcap | FileDownload | 3 | 100.0% | firmware_tampering, exploit_payload_injection |

### Did the alarm carry a plausible name?

| Capture | Named a plausible equivalent | Named something else | Label has no equivalent | Names raised |
|---|---|---|---|---|
| m08.pcap | 0 | 0 | 0 | - |
| m20.pcap | 0 | 5 | 0 | data_exfiltration x5 |
| m21.pcap | 0 | 13 | 0 | data_exfiltration x13 |
| m42.pcap | 0 | 21 | 0 | brute_force x232, dos_flood x9, exploit_payload_injection x22, data_exfiltration x22, reconnaissance_port_scan x471, credential_replay_distributed x2 |

## Label mapping used

| IoT-23 detailed label | Our names |
|---|---|
| PartOfAHorizontalPortScan | reconnaissance_port_scan |
| DDoS | dos_flood, tcp_syn_flood, icmp_ping_flood, slow_loris_exhaustion, mqtt_message_flood, dos_flood_distributed, tcp_syn_flood_distributed, icmp_ping_flood_distributed |
| C&C | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat-Attack | c2_beaconing, rogue_config_beacon |
| C&C-Mirai | c2_beaconing, rogue_config_beacon |
| C&C-Torii | c2_beaconing, rogue_config_beacon |
| C&C-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-HeartBeat-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-PartOfAHorizontalPortScan | reconnaissance_port_scan, c2_beaconing |
| FileDownload | firmware_tampering, exploit_payload_injection |
| Attack | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
