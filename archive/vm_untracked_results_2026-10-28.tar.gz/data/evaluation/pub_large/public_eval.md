# Detector on public IoT traffic (IoT-23)

Real IoT captures from the Stratosphere Laboratory's IoT-23 dataset, which the detector was never tuned on. Detection used a 60 s window over traffic in both directions. Every alarm on a benign capture is a false alarm. On malware captures an alarm is *justified* if a connection labelled Malicious overlapped the window, and a malicious second counts as *noticed* if an alarm fired within the window after it.

## Malware traffic: what it noticed

| Capture | Device | Packets | Malicious seconds | Noticed | 95% CI | Alarms | Justified | False-alarm checks | Per hour |
|---|---|---|---|---|---|---|---|---|---|
| m34.pcap | 192.168.1.195 | 4,154 | 1479 | 94.1% | [93-95%] | 1129 | 1052 | 77 | 154.31 |
| m03.pcap | 192.168.2.5 | 4,753 | 1703 | 22.0% | [20-24%] | 263 | 263 | 0 | 0.0 |

### By what the malware was doing (IoT-23's detailed label)

| Capture | Detailed label | Malicious seconds | Noticed | Plausible names of ours |
|---|---|---|---|---|
| m34.pcap | C&C | 1479 | 94.1% | c2_beaconing, rogue_config_beacon |
| m03.pcap | Attack | 141 | 98.6% | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
| m03.pcap | C&C | 1638 | 21.6% | c2_beaconing, rogue_config_beacon |
| m03.pcap | PartOfAHorizontalPortScan | 1211 | 30.9% | reconnaissance_port_scan |

### Did the alarm carry a plausible name?

| Capture | Named a plausible equivalent | Named something else | Label has no equivalent | Names raised |
|---|---|---|---|---|
| m34.pcap | 0 | 1052 | 0 | mqtt_message_flood x210, brute_force x889, dos_flood x1, reconnaissance_port_scan x29 |
| m03.pcap | 231 | 32 | 0 | credential_replay_distributed x27, exploit_payload_injection x2, brute_force x120, reconnaissance_port_scan x109, mqtt_message_flood x5 |

## Label mapping used

| IoT-23 detailed label | Our names |
|---|---|
| PartOfAHorizontalPortScan | reconnaissance_port_scan |
| DDoS | dos_flood, tcp_syn_flood, icmp_ping_flood, slow_loris_exhaustion, mqtt_message_flood, dos_flood_distributed, tcp_syn_flood_distributed, icmp_ping_flood_distributed |
| C&C | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat-Attack | c2_beaconing, rogue_config_beacon |
| C&C-Mirai | c2_beaconing, rogue_config_beacon |
| C&C-Torii | c2_beaconing, rogue_config_beacon |
| C&C-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-HeartBeat-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-PartOfAHorizontalPortScan | reconnaissance_port_scan, c2_beaconing |
| FileDownload | firmware_tampering, exploit_payload_injection |
| Attack | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
