# Generalisation tests: where the three strategies differ

## Leave-one-attack-out

20 held-out attacks. Mean regret against the measured table (lower is better; 0 means the measured-best action):

| Arm | Mean regret [95% CI] | Picks the measured-best |
|---|---|---|
| Rule-based | 3.15 [2.31, 3.91] | 3/20 |
| Stackelberg | 0.04 [0.00, 0.13] | 19/20 |
| PPO (never saw it) | 1.61 [0.85, 2.47] | 3/20 |
| Arbiter | 0.04 [0.00, 0.13] | 19/20 |
| One fixed action for all | 0.24 [0.15, 0.32] | 7/20 |

Stackelberg vs PPO (regret): better in 17, equal in 3, worse in 0 (mean difference PPO - Stackelberg +1.57, sign-test p = 0.000).

## Leave-one-class-out

17 held-out attacks. Mean regret against the measured table (lower is better; 0 means the measured-best action):

| Arm | Mean regret [95% CI] | Picks the measured-best |
|---|---|---|
| Rule-based | 3.13 [2.24, 3.94] | 3/17 |
| Stackelberg | 0.05 [0.00, 0.16] | 16/17 |
| PPO (never saw it) | 2.19 [1.20, 3.20] | 2/17 |
| Arbiter | 0.05 [0.00, 0.16] | 16/17 |
| One fixed action for all | 0.23 [0.14, 0.32] | 6/17 |

Stackelberg vs PPO (regret): better in 15, equal in 2, worse in 0 (mean difference PPO - Stackelberg +2.14, sign-test p = 0.000).

## Objective shift

Mean regret over all 21 conditions under the shifted objective (lower is better).

| Shift | Optimum changed in | Rule-based | Stackelberg rebuilt | Stackelberg stale | PPO stale | PPO retrained | Arbiter + stale PPO | One fixed action |
|---|---|---|---|---|---|---|---|---|
| service_critical | 0 | 4.90 | 1.44 | 0.14 | 0.02 | 0.02 | 0.00 | 0.69 |
| intelligence_priority | 20 | 5.52 | 2.82 | 3.13 | 3.11 | 0.01 | 0.96 | 0.15 |
| cost_averse | 1 | 3.40 | 0.00 | 0.00 | 0.10 | 0.00 | 0.00 | 1.22 |
| security_first | 0 | 3.62 | 0.02 | 0.02 | 0.01 | 0.14 | 0.00 | 0.30 |

Shift definitions: service_critical: service weight x3 (the protected device must stay reachable); intelligence_priority: intelligence weight x4 (a research honeypot); cost_averse: every action cost x4 (operations-averse); security_first: containment x1.6 and service /3 (collateral damage is acceptable).

Canonical-context decisions vs the live harness's modal choices: rule_based 21/21, stackelberg 21/21, ppo 21/21.

