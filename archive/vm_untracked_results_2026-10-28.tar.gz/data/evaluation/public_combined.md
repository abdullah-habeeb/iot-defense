# The detector on real IoT traffic (IoT-23, never used to tune it)

**before** = the live defender as first built (only traffic arriving at the host, last 5 s). **after** = traffic in both directions, last 60 s (the setting that names every lab attack correctly). Both rows use the same captures; nothing was tuned on them.

## Benign traffic: one Amazon Echo, 5.5 hours, 396,648 packets

Every alarm here is a false alarm. 'Acted on' means flagged on two checks in a row, which is when the defender changes the firewall.

| Setting | Flagged seconds | Per hour | Acted on | Per hour | What it was called (acted on) |
|---|---|---|---|---|---|
| before (5 s, inbound) | 875 | 159.48 | 154 | 28.069 | exploit_payload_injection x58, dos_flood x56, brute_force x29, data_exfiltration x6, reconnaissance_port_scan x4, buffer_overflow_probe x1 |
| after (60 s, both) | 3,257 | 593.63 | 145 | 26.428 | exploit_payload_injection x65, brute_force x24, buffer_overflow_probe x23, dos_flood x13, reconnaissance_port_scan x8, data_exfiltration x7, mqtt_message_flood x4, credential_replay x1 |

## Real malware captures

Noticed at start = an alarm fired within the window after a malicious connection began. Precision = share of alarms raised while a malicious connection was open. 'Plausible name' = the alarm carried a name from the list IoT-23's label could reasonably be (my judgement, listed at the end).

| Capture | What it is | Setting | Malicious connections | Noticed at start | Alarms | Precision | Alarm-seconds with nothing malicious open, per hour | Alarms with a plausible name |
|---|---|---|---|---|---|---|---|---|
| m03.pcap | port scanning + attacks, first 30 min (3-1) | before | 1635 | 17% | 97 | 100% | 0.0 | 97 of 97 |
| m03.pcap | port scanning + attacks, first 30 min (3-1) | after | 1635 | 43% | 263 | 100% | 0.0 | 231 of 263 |
| m34.pcap | Mirai C&C, first 30 min (34-1) | before | 284 | 26% | 113 | 83% | 38.08 | 0 of 94 |
| m34.pcap | Mirai C&C, first 30 min (34-1) | after | 284 | 98% | 1129 | 93% | 154.31 | 0 of 1052 |
| m08.pcap | C&C traffic (8-1) | before | 8222 | 0% | 0 | n/a | 0.0 | - |
| m08.pcap | C&C traffic (8-1) | after | 8222 | 0% | 0 | n/a | 0.0 | - |
| m20.pcap | Torii C&C (20-1) | before | 16 | 6% | 5 | 100% | 0.0 | 0 of 5 |
| m20.pcap | Torii C&C (20-1) | after | 16 | 81% | 1071 | 84% | 7.17 | 0 of 899 |
| m21.pcap | Torii C&C (21-1) | before | 14 | 21% | 13 | 100% | 0.0 | 0 of 13 |
| m21.pcap | Torii C&C (21-1) | after | 14 | 71% | 1806 | 98% | 1.54 | 0 of 1769 |
| m42.pcap | trojan file download (42-1) | before | 6 | 100% | 758 | 3% | 88.22 | 0 of 21 |
| m42.pcap | trojan file download (42-1) | after | 6 | 100% | 6815 | 1% | 803.88 | 0 of 99 |

### By what the malware was doing

| Capture | Setting | IoT-23 label | Connections | Noticed at start |
|---|---|---|---|---|
| m03.pcap | before | Attack | 30 | 93% |
| m03.pcap | before | C&C | 2 | 0% |
| m03.pcap | before | PartOfAHorizontalPortScan | 1603 | 16% |
| m03.pcap | after | Attack | 30 | 97% |
| m03.pcap | after | C&C | 2 | 0% |
| m03.pcap | after | PartOfAHorizontalPortScan | 1603 | 42% |
| m34.pcap | before | C&C | 284 | 26% |
| m34.pcap | after | C&C | 284 | 98% |
| m08.pcap | before | C&C | 8222 | 0% |
| m08.pcap | after | C&C | 8222 | 0% |
| m20.pcap | before | C&C-Torii | 16 | 6% |
| m20.pcap | after | C&C-Torii | 16 | 81% |
| m21.pcap | before | C&C-Torii | 14 | 21% |
| m21.pcap | after | C&C-Torii | 14 | 71% |
| m42.pcap | before | C&C-FileDownload | 3 | 100% |
| m42.pcap | before | FileDownload | 3 | 100% |
| m42.pcap | after | C&C-FileDownload | 3 | 100% |
| m42.pcap | after | FileDownload | 3 | 100% |

### What the alarms were called, per capture (after)

| Capture | Names raised |
|---|---|
| m08.pcap | (no alarms) |
| m20.pcap | credential_replay x597, mqtt_message_flood x203, credential_replay_distributed x200, reconnaissance_port_scan x44, exploit_payload_injection x22, data_exfiltration x5 |
| m21.pcap | credential_replay x1191, mqtt_message_flood x333, credential_replay_distributed x202, reconnaissance_port_scan x53, data_exfiltration x21, exploit_payload_injection x6 |
| m42.pcap | brute_force x5445, credential_replay x543, mqtt_message_flood x433, reconnaissance_port_scan x172, exploit_payload_injection x118, credential_replay_distributed x57, data_exfiltration x45, dos_flood x2 |
| m34.pcap | brute_force x889, mqtt_message_flood x210, reconnaissance_port_scan x29, dos_flood x1 |
| m03.pcap | brute_force x120, reconnaissance_port_scan x109, credential_replay_distributed x27, mqtt_message_flood x5, exploit_payload_injection x2 |

### Label mapping used (a judgement)

| IoT-23 label | Our names |
|---|---|
| PartOfAHorizontalPortScan | reconnaissance_port_scan |
| DDoS | dos_flood, tcp_syn_flood, icmp_ping_flood, slow_loris_exhaustion, mqtt_message_flood, dos_flood_distributed, tcp_syn_flood_distributed, icmp_ping_flood_distributed |
| C&C | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat | c2_beaconing, rogue_config_beacon |
| C&C-HeartBeat-Attack | c2_beaconing, rogue_config_beacon |
| C&C-Mirai | c2_beaconing, rogue_config_beacon |
| C&C-Torii | c2_beaconing, rogue_config_beacon |
| C&C-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-HeartBeat-FileDownload | firmware_tampering, rogue_config_beacon, data_exfiltration |
| C&C-PartOfAHorizontalPortScan | reconnaissance_port_scan, c2_beaconing |
| FileDownload | firmware_tampering, exploit_payload_injection |
| Attack | brute_force, exploit_payload_injection, credential_replay, buffer_overflow_probe |
